# -*- coding: utf-8 -*-
"""
Created on Mon Jul 11 09:40:10 2022

@author: LV
used for mothly cumstomer Reporter
script 
"""


import xlrd
import pandas as pd
import datetime 
import re
from interval import Interval
import warnings
#'d:/analyze program/see.xlsx'
warnings.filterwarnings('ignore')
class initialize():
    today=datetime.datetime.now()
    tomonth=int(datetime.datetime.now().strftime('%Y%m'))
    def __init__(self):
        xlsx_1=pd.ExcelFile('d:/DATABASE/all/会员台账.xls')
        xlsx_5 = pd.ExcelFile('c:/Users/LV/Desktop/DATA OF HNIEEC/业务预算/业务预算-招商服务2022-6.xlsx')
        
        self.df_1 = pd.read_excel(xlsx_1, 0)              #df1会员信息台账
        print('member book Data import successfully')
        self.df_2 = pd.read_csv('d:/DATABASE/all/销项发票明细.csv')
        print('Sale detail import successfully')
        self.df_3 = pd.read_excel('d:/DATABASE/all/客户开票.xlsx')
        print('value of trade import successfully')
        self.df_4 = pd.read_excel('d:/DATABASE/all/纳税.xlsx')
        self.df_41=pd.read_excel('d:/DATABASE/all/返税.xls',header=1)
        print('Tax Data import successfully')
        self.df_5 = pd.read_excel(xlsx_5, "收入明细表",header=1)
        print('financial statement-income import successfully')
        self.df_6 = pd.read_excel(xlsx_5, 1)                           #df6
        print('financial statement-others import successfully')
        self.df_7 = pd.read_excel('d:/DATABASE/taxrate/返税比例.xlsx') #df7返税比例
        self.df_8 = pd.read_excel('d:/DATABASE/all/洋浦完税证明.xlsx',header=1)  #df8完税证明
        self.df_9 = pd.read_excel('d:/DATABASE/cargotype/产品字典库.xlsx')  #df9产品字典库
        self.list_re_cargo=list(self.df_9['key'])
        self.dict_type=dict(zip(self.df_9['key'],self.df_9['type']))
        print('All Data import successfully')
        self.namedict = dict(zip(self.df_1['统一社会信用代码'],self.df_1['企业名称']))
        self.df_2['开票月份']=self.df_2['开票日期'].str[:7]
    def feedback(self,a):
        if a==1:
            return self.df_1
        if a==2:
            return self.df_2
        if a==3:
            return self.df_3
        if a==4:
            return self.df_4
        if a==5:
            return self.df_5
        if a==6:
            return self.df_6
        if a==7:
            return self.namedict
        
    def add_type(self):
        rate_list=[]
        df_2=self.df_2
        cargolist=list(self.df_2['商品和服务分类'])
        cargotype=[]
        for i in cargolist:

            for x in self.list_re_cargo:
                pattern = re.compile(r'(.*)'+x)
                result1 = pattern.search(str(i))
                if result1 != None:
                    cargotype.append(self.dict_type.get(x))
                    break
            if result1 == None:
                cargotype.append('unknow')

        df_2['type']=cargotype

        return df_2
    def add_name(self,pd,a):
        listname=[]
        if a==0:
            for i in pd.index:
                listname.append(self.namedict.get(i))
            pd.insert(0,'企业名称',listname)
        else:
            for i in list(pd['统一社会信用代码']):
                listname.append(self.namedict.get(i))
            pd.insert(0,'企业名称',listname)
        return pd
        
    def Sale_calculate(self,start=202001,end=tomonth,place='全部',method='all',whole=True):
        if whole==False:
            df_3=self.df_3.drop(self.df_3[(self.df_3['销方企业名称']=='海南迈科供应链管理有限公司')|(self.df_3['销方企业名称']=='海南兴威供应链有限公司')|(self.df_3['销方企业名称']=='海南泰智有色金属有限公司')|(self.df_3['销方企业名称']=='智威（海南）新材料科技有限公司')].index)
            df_2=self.df_2.drop(self.df_2[(self.df_2['销方企业名称']=='海南迈科供应链管理有限公司')|(self.df_2['销方企业名称']=='海南兴威供应链有限公司')|(self.df_2['销方企业名称']=='海南泰智有色金属有限公司')|(self.df_2['销方企业名称']=='智威（海南）新材料科技有限公司')].index)   

        if whole==True:
            df_3=self.df_3
            df_2=self.df_2
       
        if place != '全部':
            df_3=df_3[df_3['注册地']==place]
            df_2=df_2[df_2['销方企业注册地']==place]
            
        if method=='all':
            mask=(df_3['开票月份'] >= start) & (df_3['开票月份'] <= end) 
            userange=df_3.loc[mask]
            result=userange.groupby(['统一社会信用代码']).sum()['价税合计']
            listname=[]
            for i in result.index:
                listname.append(self.namedict.get(i))
            dict_result={'统一社会信用代码' :result.index,'企业名称':listname,'价税合计':result.values}
            result1=pd.DataFrame(dict_result)
            return result1
    
        if method == 'goods':
            start_new=str(start)[:4]+'-'+str(start)[4:6]
            end_new=str(end)[:4]+'-'+str(end)[4:6]
            mask=(df_2['开票日期'] >= start_new) & (df_2['开票日期'] <= end_new) 
            userange=df_2.loc[mask]
            result=userange.groupby(['商品和服务分类','开票月份']).sum('价税合计')
            result=result.unstack()
            result.reset_index(inplace=True)
            result.drop(columns=['发票代码','发票号码','销方客户编号','含税单价（元）'],inplace=True)
            return result
        if method == 'type':
            rate_list=[]
            start_new=str(start)[:4]+'-'+str(start)[4:6]
            end_new=str(end)[:4]+'-'+str(end)[4:6]
            mask=(df_2['开票日期'] >= start_new) & (df_2['开票日期'] <= end_new)
            userange=df_2.loc[mask]

            cargolist=list(userange['商品和服务分类'])
            cargotype=[]
            for i in cargolist:

                for x in self.list_re_cargo:
                    pattern = re.compile(r'(.*)'+x)
                    result1 = pattern.search(str(i))
                    if result1 != None:
                        cargotype.append(self.dict_type.get(x))
                        break
                if result1 == None:
                    cargotype.append('unknow')
            userange['type']=cargotype
            result=userange.groupby(['统一社会信用代码','开票月份','type']).sum()['价税合计（元）']
            result=result.unstack()
            result.reset_index(inplace=True)
            result=self.add_name(result,1)
            return result

                
    def Tax_calculate(self,start=202001,end=tomonth,place='',method='all',whole=True): 
        if whole==False:
            try:
                df_4=self.df_4.drop(self.df_4[(self.df_4['公司名称']=='海南迈科供应链管理有限公司')|(self.df_4['公司名称']=='海南兴威供应链有限公司')|(self.df_4['公司名称']=='海南泰智有色金属有限公司')|(self.df_4['公司名称']=='智威（海南）新材料科技有限公司')].index)
            except:pass
        if whole==True:
            df_4=self.df_4
        
        if place=='海口':
            df_4=df_4[df_4['纳税地']==place] 
            mask=(df_4['所属月份'] >= start) & (df_4['所属月份'] <= end) 
            userange=df_4.loc[mask]
            if method=='all':            
                result=userange.groupby(['统一社会信用代码']).sum()['合计']
                listname=[]
                for i in result.index:
                    listname.append(self.namedict.get(i))
                dict_result={'统一社会信用代码' :result.index,'企业名称':listname,'纳税合计':result.values}
                result1=pd.DataFrame(dict_result)
                return result1 
        
            if method=='type':
                result=userange.groupby(['统一社会信用代码']).sum()
                
                result.drop(columns=['所属月份'],inplace=True)
                listname=[]
                for i in result.index:
                    listname.append(self.namedict.get(i))
                result.insert(0,'企业名称',listname)
                result=result.reset_index()
                return result
        if place=='洋浦':
            df_4=df_4[df_4['纳税地']==place] 
            mask=(df_4['所属月份'] >= start) & (df_4['所属月份'] <= end) 
            userange=df_4.loc[mask]
            if method=='all':            
                result=userange.groupby(['统一社会信用代码']).sum()['合计']
                listname=[]
                for i in result.index:
                    listname.append(self.namedict.get(i))
                dict_result={'统一社会信用代码' :result.index,'企业名称':listname,'纳税合计':result.values}
                result1=pd.DataFrame(dict_result)
                return result1 
            if method=='type':
               result=userange.groupby(['统一社会信用代码']).sum()
               
               result.drop(columns=['所属月份'],inplace=True)
               listname=[]
               for i in result.index:
                   listname.append(self.namedict.get(i))
               result.insert(0,'企业名称',listname)
               result=result.reset_index()
               return result
        else:
            mask=(df_4['所属月份'] >= start) & (df_4['所属月份'] <= end) 
            userange=df_4.loc[mask]
            if method=='all':            
                result=userange.groupby(['统一社会信用代码']).sum()['合计']
                listname=[]
                for i in result.index:
                    listname.append(self.namedict.get(i))
                dict_result={'统一社会信用代码' :result.index,'企业名称':listname,'纳税合计':result.values}
                result1=pd.DataFrame(dict_result)
                return result1 
            if method=='type':
                result=userange.groupby(['统一社会信用代码']).sum()
                
                result.drop(columns=['所属月份'],inplace=True)
                listname=[]
                for i in result.index:
                    listname.append(self.namedict.get(i))
                result.insert(0,'企业名称',listname)
                result=result.reset_index()
                return result
    def TaxBack_calculate(self,start=202001,end=tomonth,place='',method='all',whole=True): 
        if whole==False:
            try:
               df_41=self.df_41=self.df_41.drop(self.df_41[(self.df_41['会员企业名称']=='海南迈科供应链管理有限公司')|(self.df_41['会员企业名称']=='海南兴威供应链有限公司')|(self.df_41['会员企业名称']=='海南泰智有色金属有限公司')|(self.df_41['会员企业名称']=='智威（海南）新材料科技有限公司')].index)
            except:pass
        if whole==True:
            df_41=self.df_41
            
        if place=='海口':
            df_41=df_41[df_41['纳税地']==place] 

                    
            mask=(df_41['税收所属期'] >= start) & (df_41['税收所属期'] <= end) 
            userange=df_41.loc[mask]
            if method=='all':            
                result=userange.groupby(['统一社会信用代码']).sum()

                result.drop(columns=['税收所属期'],inplace=True)
                return result
            if method=='apply':
                result=userange.groupby(['统一社会信用代码']).sum()

                result.drop(columns=['税收所属期','纳税合计','增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '实返合计', '增值税.2', '城建税.2',
                                     '教育费附加.2', '印花税.2', '企业所得税.2', '金额', '原因', '应付', '已收', 
                                      'Unnamed: 35'],inplace=True)
                return result

            if method=='real':
                result=userange.groupby(['统一社会信用代码']).sum()

                result.drop(columns=['税收所属期','纳税合计', '增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '申请合计', '增值税.1', '城建税.1',
                                     '教育费附加.1', '印花税.1', '企业所得税.1'],inplace=True)
                return result
                        
        if place=='洋浦':
            df_41=df_41[self.df_41['纳税地']==place] 

            mask=(df_41['税收所属期'] >= start) & (df_41['税收所属期'] <= end) 
            userange=df_41.loc[mask]
            if method=='all':            
                result=userange.groupby(['统一社会信用代码']).sum()

                result.drop(columns=['税收所属期'],inplace=True)
                return result
            if method=='apply':
                result=userange.groupby(['统一社会信用代码']).sum()

                result.drop(columns=['税收所属期','纳税合计','增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '实返合计', '增值税.2', '城建税.2',
                                     '教育费附加.2', '印花税.2', '企业所得税.2', '金额', '原因', '应付', '已收', 
                                      'Unnamed: 35'],inplace=True)
                return result

            if method=='real':
                result=userange.groupby(['统一社会信用代码']).sum()
  
                result.drop(columns=['税收所属期','纳税合计', '增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '申请合计', '增值税.1', '城建税.1',
                                     '教育费附加.1', '印花税.1', '企业所得税.1'],inplace=True)
                return result
          
        else:
            df_41=self.df_41
            mask=(df_41['税收所属期'] >= start) & (df_41['税收所属期'] <= end) 
            userange=df_41.loc[mask]
            if method=='all':            
                result=userange.groupby(['统一社会信用代码']).sum()

                result.drop(columns=['税收所属期'],inplace=True)
                return result
            if method=='apply':
                result=userange.groupby(['统一社会信用代码']).sum()

                result.drop(columns=['税收所属期','纳税合计','增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '实返合计', '增值税.2', '城建税.2',
                                     '教育费附加.2', '印花税.2', '企业所得税.2', '金额', '原因', '应付', '已收', 
                                      'Unnamed: 35'],inplace=True)
                return result

            if method=='real':
                result=userange.groupby(['统一社会信用代码']).sum()

                result.drop(columns=['税收所属期','纳税合计', '增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '申请合计', '增值税.1', '城建税.1',
                                     '教育费附加.1', '印花税.1', '企业所得税.1'],inplace=True)
                return result
            
    def all_calculate(self,start=202001,end=tomonth,place='',method='all',whole=True):
        result_sale=self.Sale_calculate(start,end,place=place,method='all',whole=whole)
        result_tax=self.Tax_calculate(start,end,place=place,method='type',whole=whole)
        result_taxback_detail=self.TaxBack_calculate(start,end,place=place,method='all',whole=whole)
        result1=pd.merge(result_sale,result_tax,on='统一社会信用代码',how='outer')
        result=pd.merge(result1,result_taxback_detail,on='统一社会信用代码',how='outer')
        try:
            result.drop(columns=['纳税合计', '增值税', '城建税_y', '教育费附加_y', '地方教育费附加_y',
                                 '印花税_y', '企业所得税_y', '个税', '增值税.1', '城建税.1', '教育费附加.1', '印花税.1',
                                 '企业所得税.1', '增值税.2', '城建税.2', '教育费附加.2', '印花税.2', '企业所得税.2',
                                 '金额_y', '原因', '应付', '已收', 'Unnamed: 35' ],inplace=True)
        except:pass
        listname=[]
        bo=list(result['统一社会信用代码'])
        for i in bo:
            listname.append(self.namedict.get(i))
        result.insert(0,'企业名称',listname)
        result=result.reset_index()
        order=['统一社会信用代码','企业名称','价税合计','合计','实缴增值税','城建税_x','教育费附加_x','地方教育费附加_x','印花税_x','企业所得税_x','个人所得税','其他收入-工会经费','申请合计','实返合计']
        return result[order]
            
    def report(self,start=202001,end=tomonth,place='',method='all',whole=True):
        mask3=(self.df_3['开票月份'] >= start) & (self.df_3['开票月份'] <= end) 
        df_3=self.df_3.loc[mask3]
        mask4=(self.df_4['所属月份'] >= start) & (self.df_4['所属月份'] <= end) 
        df_4=self.df_4.loc[mask4]
        mask41=(self.df_41['税收所属期'] >= start) & (self.df_41['税收所属期'] <= end) 
        df_41=self.df_41.loc[mask41]
        if whole == False:
            try:
                df_3=df_3.drop(df_3[(df_3['销方企业名称']=='海南迈科供应链管理有限公司')|(df_3['销方企业名称']=='海南兴威供应链有限公司')|(df_3['销方企业名称']=='海南泰智有色金属有限公司')|(df_3['销方企业名称']=='智威（海南）新材料科技有限公司')].index)
                df_4=df_4.drop(df_4[(df_4['公司名称']=='海南迈科供应链管理有限公司')|(df_4['公司名称']=='海南兴威供应链有限公司')|(df_4['公司名称']=='海南泰智有色金属有限公司')|(df_4['公司名称']=='智威（海南）新材料科技有限公司')].index)
            except:pass
        if place== '海口':
            df_3=df_3[df_3['注册地']==place]
            df_4=df_4[df_4['纳税地']==place] 
            df_41=df_41[df_41['纳税地']==place] 
        if place== '洋浦':
            df_3=df_3[df_3['注册地']==place]
            df_4=df_4[df_4['纳税地']==place] 
            df_41=df_41[df_41['纳税地']==place] 
        result_sale=df_3.groupby(['开票月份']).sum().drop(columns=['客户编号','累计价税合计','份数','金额','税额'])
        result_tax=df_4.groupby(['所属月份']).sum()
        result_taxback_apply=df_41.groupby(['税收所属期']).sum().drop(columns=['纳税合计', '增值税', '城建税', '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税','城建税.2', '教育费附加.2', '印花税.2', '企业所得税.2', '金额', '原因',  '已收'])
        result_taxback_real=df_41.groupby(['税收所属期']).sum().drop(columns=['纳税合计', '增值税', '城建税', '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税','申请合计','增值税.1', '城建税.1', '教育费附加.1', '印花税.1', '企业所得税.1','金额', '原因',  '已收'])
        result_taxback_detail=df_41.groupby(['税收所属期']).sum()

        if method == 'all_detail':
            result=pd.merge(pd.merge(result_sale,result_tax,left_index=True,right_index=True,how='left'),result_taxback_real,left_index=True,right_index=True,how='left')
            return result
        if method == 'all':
            result=pd.merge(pd.merge(result_sale,result_tax,left_index=True,right_index=True,how='left'),result_taxback_detail,left_index=True,right_index=True,how='left')
            return result
        if method == 'sale':       
            return result_sale
        if method == 'tax':       
            return result_tax
        if method == 'taxback_apply':       
            return result_taxback_apply
        if method == 'taxback_real':       
            return result_taxback_real
        if method == 'taxback_detail':       
            return result_taxback_detail
  
    def rawmerge(self,start=202001,end=tomonth,place='',method='all',whole=True):
        df3=self.df_3
        df3['key']=df3['统一社会信用代码']+df3['开票月份'].astype('str')
        df4=self.df_4
        df4['key']=df4['统一社会信用代码']+df4['所属月份'].astype('str')
        df41=self.df_41
        df41['key']=df41['统一社会信用代码']+df41['税收所属期'].astype('str')
        result1=pd.merge(df3,df4,on='key',how='outer')
        result=pd.merge(result1,df41,on='key',how='outer')
        result['统一社会信用代码']=result['key'].str[:-6]
        bo=list(result['统一社会信用代码'])
        listname=[]
        for i in bo:
            listname.append(self.namedict.get(i))
        result.insert(0,'企业名称',listname)
        result['年月']=result['key'].str[-6:]
        
        return result
    
    def sale_rate(self,start='0000/00/00',end='0000/00/00',ID=''):
        rate_list=[]
        df_2=self.df_2
        start=start.replace('/','-')
        end=end.replace('/','-')
        mask=(df_2['开票日期'] >= start) & (df_2['开票日期'] <= end) & (df_2['统一社会信用代码'] == ID)
        userange=df_2.loc[mask]

        cargolist=list(userange['商品和服务分类'])

        cargotype=[]
        for i in cargolist:

            for x in self.list_re_cargo:
                pattern = re.compile(r'(.*)'+x)
                result1 = pattern.search(str(i))
                if result1 != None:
                    cargotype.append(self.dict_type.get(x))
                    break
            if result1 == None:
                cargotype.append('unknow')
        userange['type']=cargotype
        s1=userange.groupby(['type']).sum()['价税合计（元）']
        try:
            v0=sum(s1)
        except:v0=0
            
        try:
            v1=s1.energy
        except:v1=0
        try:
            v2=s1.unenergy
        except:v2=0
        try:
            v3=s1.other
        except:v3=0
        try:
            v4=s1.unknow
        except:v4=0
        default_list=[1,0,0,0,1]  #默认参数，第一位能源类占比，第二位非能源占比，第三位其他占比，第四位未知占比，第五位是否为缺省值
                                #缺省值为能源100%，缺省值为1
        if v0 == 0:
            return default_list
        else:
            rate_list=[v1/v0,v2/v0,v3/v0,v4/v0,0]
            return rate_list
                
  
    def tax_cube(self,from_date=202201,end_date=tomonth,replace=True,need='raw'):
        rate_df=self.df_7
        YP_df=self.df_8       
        mask=(YP_df['Unnamed: 8'] >= from_date) & (YP_df['Unnamed: 8'] <= end_date)
        userange=YP_df.loc[mask]
        result=pd.DataFrame()
        for i in range(len(userange)):
            Serie=userange.iloc[i]
            s1=Serie.dropna() 
            if len(s1)<11:
                pass
            else:
                rate_s=self.sale_rate(start=Serie['起始日'],end=Serie['截止日'],ID=Serie['Unnamed: 2'])
                v1=s1.iloc[9]*rate_df[s1.index[9]][1]*rate_s[0]
                v2=s1.iloc[9]*rate_df[s1.index[9]][2]*rate_s[1]
    
                v0=v1+v2
                Serie['申请合计']=v0
                Serie['增值税.1']=0
                Serie['城建税.1']=0
                Serie['教育费附加.1']=0
                Serie['印花税.1']=0
                Serie['企业所得税.1']=0
                Serie['个税.1']=0
                list_kind=['增值税','城建税','教育费附加','印花税','企业所得税','个税']
                for i in list_kind:
                    if i == Serie['Unnamed: 7']:
                        n=i+'.1'
                        Serie[n]=v0              
                Serie['能源类应返']=v1
                Serie['非能源类应返']=v2
                Serie['能源类占比']=rate_s[0]
                Serie['非能源类占比']=rate_s[1]
                Serie['不能返占比']=rate_s[2]
                Serie['未知占比']=rate_s[3]
                Serie['是否用了缺省值']=rate_s[4]
                result=result.append(Serie,ignore_index=True)   
                result.drop(columns=['Unnamed: 0'])
                
        if need == 'raw':        
            return result
        else:
            result=result.groupby(['Unnamed: 2','Unnamed: 8']).sum()
            result.reset_index(inplace=True)
            result.rename(columns={'Unnamed: 2':'统一社会信用代码','Unnamed: 8':'税款所属期'},inplace=True)
            result=self.add_name(result,1)
            return result
        #if replace ==True:
            


    
    #企业在当前日期，服务周期内的开票金额
    #date用整数类型，ID用统一社会信用代码
    def period_sale(self,date,ID):
        df_1=self.df_1
        df_3=self.df_3
        df_1.index=df_1['统一社会信用代码']
        temp=df_1.loc[ID,:]
        start_date_raw=temp.服务期限起始
        start_date=int(start_date_raw[:4]+start_date_raw[5:7])
        zoom1=Interval(start_date,start_date+100)
        zoom2=Interval(start_date+100,start_date+200)
        zoom3=Interval(start_date+200,start_date+300)
        listA=[zoom1,zoom1,zoom1]
        for i in listA:
            if date in i:
                mask=(df_3['开票月份'] >= i.lower_bound) & (df_3['开票月份'] < i.upper_bound) &(df_3['统一社会信用代码'] == ID) 
                userange=df_3.loc[mask]
        result=sum(userange['价税合计'])
        return result

#查询匹配功能-用以索引每个公司当前的
    def querry():
        print ('请将需要查询信息的公司在模板中输入>>>')
        df_que = pd.read_excel('d:/analyze program/查询匹配/查询列表.xlsx')
        tomonth=int(datetime.datetime.now().strftime('%Y%m'))
        DATA=initialize()
        df_1=DATA.feedback(3)
        DF_trade=df_1[df_1['开票月份']==tomonth]
        sum_dict=dict(zip(DF_trade['销方企业名称'],DF_trade['累计价税合计']))
        namelist=df_que['公司名称']
        resultlist=[]
        count1,count2= 0,0
        for i in namelist:
            try:
                resultlist.append(sum_dict[i])
                count1+=1
            except:
                resultlist.append('未查询到')
                count2+=1
        result=pd.DataFrame({'公司名称':namelist,'累计价税合计':resultlist})
        
        df_2=DATA.feedback(4)
        tax_result=df_2.groupby(['公司名称']).sum(['合计','实缴增值税','城建税','教育费附加','地方教育费附加','印花税','企业所得税','个人所得税','其他收入-工会经费'])
        result=pd.merge(result, tax_result.drop(columns=['所属月份']),how='left',on='公司名称')
        
        count=count1+count2
        print(result)
        print('querry finished !')
        print('total '+str(count))
        print('Find '+str(count1))
        print('No match '+str(count2))
        result.to_excel('d:/analyze program/匹配结果/匹配结果.xlsx',index=None)
       
    def querry(start,end):
        print ('请将需要查询信息的公司在模板中输入>>>')
        print ('查询的时间区间为'+str(start)+'>>>'+str(end))
        df_que = pd.read_excel('d:/analyze program/查询匹配/查询列表.xlsx')
        DATA=initialize()
        df_1=DATA.feedback(3)
        DF_trade=df_1[df_1['开票月份']==end]
        DF_trade_star=df_1[df_1['开票月份']==start]
        sum_dict=dict(zip(DF_trade['销方企业名称'],DF_trade['累计价税合计']-DF_trade_star['累计价税合计']+DF_trade_star['价税合计']))
        namelist=df_que['公司名称']
        resultlist=[]
        count1,count2= 0,0
        for i in namelist:
            try:
                resultlist.append(sum_dict[i])
                count1+=1
            except:
                resultlist.append('未查询到')
                count2+=1
        result=pd.DataFrame({'公司名称':namelist,'累计价税合计':resultlist})
        
        df_raw=DATA.feedback(4)
        mask=(df_raw['所属月份'] >= start) & (df_raw['所属月份'] <= end)
        df_2=df_raw.loc[mask]
        tax_result=df_2.groupby(['公司名称']).sum(['合计','实缴增值税','城建税','教育费附加','地方教育费附加','印花税','企业所得税','个人所得税','其他收入-工会经费'])
        result=pd.merge(result, tax_result.drop(columns=['所属月份']),how='left',on='公司名称')
        
        count=count1+count2
        print(result)
        print('querry finished !')
        print('total '+str(count))
        print('Find '+str(count1))
        print('No match '+str(count2))
        result.to_excel('d:/analyze program/匹配结果/匹配结果.xlsx',index=None)
    

    
#日常查询数据


    


#while(True):
#    print('请输入功能:0.自动下载数据 1.数据报表 2.报告制作 3.数据分析 9.退出')
#    a=input()
#    if a=='0':
#        at.autoDownload()


