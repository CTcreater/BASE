import tkinter
import tkinter.ttk
def SetupStyle():
    style = tkinter.ttk.Style()
    return style
