# -*- coding: utf-8 -*-
"""
Created on Wed Jul 13 13:47:00 2022

@author: LV
"""

import requests
import re
import urllib
import datetime
import xlrd
import numpy as np
import pandas as pd
import warnings
import calendar

if __name__=='__main__':

    warnings.filterwarnings('ignore')
    def autoDownload():
        today=datetime.datetime.now().strftime('%Y%m%d')
        tomonth=datetime.datetime.now().strftime('%Y%m')
        #登陆获取cookies
        url_login='https://www.hntradesp.com/ocrm/login'
        Payload_login={
            'username':'lvchangting',
            'password': 'lvchangting123',
            'rememberMe': 'false'
            }
        response_login=requests.post(url_login,data=Payload_login)
        cookies_login =re.findall("'Set-Cookie': '(.*?);", str(response_login.headers))
        
        #开票数据统计按企业统计（按时间筛选）
        url_salesStatistics='https://www.hntradesp.com/ocrm/tax/salesStatistics/exportExcelData'
        Payload_salesStatistics={
            'invoiceDateStart': "202003",
            'invoiceDateEnd': tomonth,
            }
        head_salesStatistics={'Cookie': cookies_login[0]}
        response_salesStatistics=requests.post(url_salesStatistics,data=Payload_salesStatistics,headers=head_salesStatistics)
        Fname_salesStatistics=urllib.parse.quote(re.findall('"msg":"(.*?)"', response_salesStatistics.text)[0])
        url_Fname_salesStatistics_real='https://www.hntradesp.com/ocrm/common/download?fileName='+Fname_salesStatistics
        file_info = requests.get(url_Fname_salesStatistics_real,data=Payload_salesStatistics,headers=head_salesStatistics)
        with open(r'd:/DATABASE/SYSreporter/'+today+'客户开票.xlsx', 'wb') as file:
            file.write(file_info.content)
        with open(r'd:/DATABASE/all/'+'客户开票.xlsx', 'wb') as file:
            file.write(file_info.content)
        print("开票数据导出完成...")
        
        
        #纳税明细导出
        url_tax=' https://www.hntradesp.com/ocrm/tax/taxStatisticsInfo/exportExcelData'
        Payload_tax={
            'isAsc': 'asc',
             }
        head_tax={'Cookie': cookies_login[0]}
        response_tax=requests.post(url_tax,data=Payload_tax,headers=head_tax)
        Fname_tax=urllib.parse.quote(re.findall('"msg":"(.*?)"', response_tax.text)[0])
        url_Fname_tax_real='https://www.hntradesp.com/ocrm/common/download?fileName='+Fname_tax
        file_tax = requests.get(url_Fname_tax_real,data=Payload_tax,headers=head_tax)
        with open(r'd:/DATABASE/Tax/'+today+'纳税.xlsx', 'wb') as file:
            file.write(file_tax.content)
        with open(r'd:/DATABASE/all/'+'纳税.xlsx', 'wb') as file:
            file.write(file_tax.content)
        print("纳税数据导出完成")
            
        #销项发票导出
        now=datetime.datetime.now()

        
        
        last_date=datetime.date(now.year, now.month-2, 1)
        recent_date=datetime.date(now.year, now.month-1, 1)
        Last_date_a=last_date.strftime('%Y-%m')+'-01'
        Last_date_b=last_date.strftime('%Y-%m')+'-31'
        path='d:/DATABASE/Saledetail/'
        history_file=last_date.strftime('%Y-%m')+'前所有历史开票明细报表.xlsx'
        recent_date_a=recent_date.strftime('%Y-%m')+'-01'
        recent_date_b=recent_date.strftime('%Y-%m')+'-31'
        fomer2_file=Last_date_a+'-'+Last_date_b+'销项发票明细.xlsx'
        fomer1_file=recent_date_a+'-'+recent_date_b+'销项发票明细.xlsx'
        try:
            xlsx_12=pd.ExcelFile(path+fomer2_file)
            xlsx_13=pd.ExcelFile(path+fomer1_file)
            df_12 = pd.read_excel(xlsx_12, 0,dtype={'发票号码':np.str_,'发票代码':np.str_})  #这个是前个月的
            df_13 = pd.read_excel(xlsx_13, 0,dtype={'发票号码':np.str_,'发票代码':np.str_})
        except:pass
        url_detail='https://www.hntradesp.com/ocrm/member/invoice/detailexport.ajax'
        Payload_detail={
            'startInvoiceTime': Last_date_a,
            'endInvoiceTime': Last_date_b,
            }
        head_detail={'Cookie': cookies_login[0]}
        response_detail=requests.post(url_detail,data=Payload_detail,headers=head_detail)
        Fname_detail=urllib.parse.quote(re.findall('"msg":"(.*?)"', response_detail.text)[0])
        url_Fname_detail_real='https://www.hntradesp.com/ocrm/common/download?fileName='+Fname_detail
        file_info_detail = requests.get(url_Fname_detail_real,data=Payload_detail,headers=head_detail)
        with open(r'd:/DATABASE/Saledetail/'+Last_date_a+'-'+Last_date_b+'销项发票明细.xlsx', 'wb') as file:
            file.write(file_info_detail.content) 
    
        print("前个月销项发票数据导出完成...")
        
        
        
    
        Payload_detail_recent={
            'startInvoiceTime': recent_date_a,
            'endInvoiceTime': recent_date_b,
            }
        response_detail_recent=requests.post(url_detail,data=Payload_detail_recent,headers=head_detail)
        Fname_detail_recent=urllib.parse.quote(re.findall('"msg":"(.*?)"', response_detail_recent.text)[0])
        url_Fname_detail_real='https://www.hntradesp.com/ocrm/common/download?fileName='+Fname_detail_recent
        file_info_detail_recent = requests.get(url_Fname_detail_real,data=Payload_detail_recent,headers=head_detail)
        with open(r'd:/DATABASE/Saledetail/'+recent_date_a+'-'+recent_date_b+'销项发票明细.xlsx', 'wb') as file:
            file.write(file_info_detail_recent.content) 
    
        print("上个月销项发票数据导出完成...")
        
    
        xlsx_1=pd.ExcelFile(path+history_file)
        xlsx_2=pd.ExcelFile(path+fomer2_file)
        xlsx_3=pd.ExcelFile(path+fomer1_file)
        df_1 = pd.read_excel(xlsx_1, 0,dtype={'发票号码':np.str_,'发票代码':np.str_})
        df_2 = pd.read_excel(xlsx_2, 0,dtype={'发票号码':np.str_,'发票代码':np.str_})  #这个是前个月的
        df_3 = pd.read_excel(xlsx_3, 0,dtype={'发票号码':np.str_,'发票代码':np.str_})
        
        if df_12['价税合计（元）'].sum()!=df_2['价税合计（元）'].sum():
            print(last_date.strftime('%Y-%m')+'历史数据发生变动！！！')
        df_2sum_dict=dict(df_2.groupby(['销方企业名称']).sum()['价税合计（元）'])
        df_12sum_dict=dict(df_12.groupby(['销方企业名称']).sum()['价税合计（元）'])
        df_2_cusname=list(set(df_2['销方企业名称']))
        dict_incharge=dict(zip(df_2['销方企业名称'],df_2['导入账户']))
        for i in df_2_cusname:
            try:
                a=df_2sum_dict.get(i)-df_12sum_dict.get(i)
            except:a=df_2sum_dict.get(i)
            if a*a >1:
                print(i+"新增加了"+'{:.2}'.format(a)+'元,上传人：'+dict_incharge.get(i))
            
        
        
        
        else:print(last_date.strftime('%Y-%m')+'开票历史数据未变动')
        if df_13['价税合计（元）'].sum()!=df_3['价税合计（元）'].sum():
            print(recent_date.strftime('%Y-%m')+'历史数据发生变动！！！') 
        df_3sum_dict=dict(df_3.groupby(['销方企业名称']).sum()['价税合计（元）'])
        df_13sum_dict=dict(df_13.groupby(['销方企业名称']).sum()['价税合计（元）'])
        df_3_cusname=list(set(df_3['销方企业名称']))
        dict_incharge=dict(zip(df_3['销方企业名称'],df_3['导入账户']))
        for i in df_3_cusname:
            try:
                a=df_3sum_dict.get(i)-df_13sum_dict.get(i)
            except:a=df_3sum_dict.get(i)
            if a*a >1:
                print(i+"新增加了"+'{:.2}'.format(a)+'元,上传人：'+dict_incharge.get(i))
            
        
      
        else:print(recent_date.strftime('%Y-%m')+'开票历史数据未变动')
        
        
        
        
        
        
        df_newhistory=df_1.append(df_2, ignore_index=True)
        newhistory_file='d:/DATABASE/Saledetail/'+recent_date.strftime('%Y-%m')+'前所有历史开票明细报表.xlsx'
        df_newhistory.to_excel(newhistory_file,index=None)
        
        print('截至'+recent_date.strftime('%Y-%m')+'的销项发票数据已更新...')
        df_all=df_1.append(df_2.append(df_3,ignore_index=True), ignore_index=True)
        df_all.to_csv('d:/DATABASE/all/销项发票明细.csv',index=None,encoding='utf_8_sig')
        print('所有销项发票已合成')
    
    
        #返税数据导出
        url_tax_back='https://www.hntradesp.com/ocrm/tax/rebate/export.ajax?taxRebateCorpNo=&taxDateStart=&taxDateEnd=&taxRebateCity=&taxTotal='
        file_info_tax_back = requests.get(url_tax_back,headers=head_tax)
        with open(r'd:/DATABASE/Taxback/'+today+'返税.xls', 'wb') as file:
            file.write(file_info_tax_back.content)
        with open(r'd:/DATABASE/all/'+'返税.xls', 'wb') as file:
            file.write(file_info_tax_back.content)
        print("返税数据导出完成")
        #会员信息导出
        url_cus='https://www.hntradesp.com/ocrm/tax/customerAccount/exportExcelData?request=customerInfoId=&regCity=&businessAgentId=&referee=&contractSignDateStr=&serviceDateStr=&deptId=&customerInfoId='
        file_info_cus = requests.get(url_cus,headers=head_tax)
        with open(r'd:/DATABASE/CustomersInfo/'+today+'会员台账.xls', 'wb') as file:
            file.write(file_info_cus.content)
        with open(r'd:/DATABASE/all/'+'会员台账.xls', 'wb') as file:
            file.write(file_info_cus.content)
        print("会员数据导出完成")
        print("所有数据导出完成")
    def TaxDownload_seg(stardate=202201,enddate=202207):
     #   https://www.hntradesp.com/ocrm/tax/taxDutyPaidProof/exportDetailData?mode=address&city=HK&customerNo=&taxMonthStart=&taxMonthEnd=&taxInputStartDate=2022-01-01&taxInputEndDate=2022-01-31
        url_login='https://www.hntradesp.com/ocrm/login'
        Payload_login={
            'username':'lvchangting',
            'password': 'lvchangting123',
            'rememberMe': 'false'
            }
        response_login=requests.post(url_login,data=Payload_login)
        cookies_login =re.findall("'Set-Cookie': '(.*?);", str(response_login.headers))
        head_tax={'Cookie': cookies_login[0]}

        lenth=(int(str(enddate)[:4])-int(str(stardate)[:4]))*12-int(str(stardate)[4:6])+int(str(enddate)[4:6])
        d = datetime.date(int(str(stardate)[:4]),int(str(stardate)[4:6]), 1)
        for i in range(lenth+1):

            this_month_start = datetime.date(d.year+(int(str(stardate)[4:6])+i)//12, d.month+i-(int(str(stardate)[4:6])+i)//13*12, 1)
            this_month_end = datetime.date(d.year+(int(str(stardate)[4:6])+i)//12, d.month+i-(int(str(stardate)[4:6])+i)//13*12, calendar.monthrange(d.year+(int(str(stardate)[4:6])+i)//12, d.month+i-(int(str(stardate)[4:6])+i)//13*12)[1])
            star='taxInputStartDate='+this_month_start.strftime('%Y-%m-%d')
            end='&taxInputEndDate='+this_month_end.strftime('%Y-%m-%d')
            url_seg='https://www.hntradesp.com/ocrm/tax/taxDutyPaidProof/exportDetailData?mode=address&city=HK&customerNo=&taxMonthStart=&taxMonthEnd=&'+star+end
            file_info = requests.get(url_seg,headers=head_tax)
            with open(r'd:/DATABASE/Taxproof/'+this_month_start.strftime('%Y-%m')+'完税证明.xlsx', 'wb') as file:
                file.write(file_info.content)
            
            print(this_month_start.strftime('%Y-%m')+"完税证明导出完成...")
    def TaxDownload(stardate=202201,enddate=202207):
     #   https://www.hntradesp.com/ocrm/tax/taxDutyPaidProof/exportDetailData?mode=address&city=HK&customerNo=&taxMonthStart=&taxMonthEnd=&taxInputStartDate=2022-01-01&taxInputEndDate=2022-01-31
        url_login='https://www.hntradesp.com/ocrm/login'
        Payload_login={
            'username':'lvchangting',
            'password': 'lvchangting123',
            'rememberMe': 'false'
            }
        response_login=requests.post(url_login,data=Payload_login)
        cookies_login =re.findall("'Set-Cookie': '(.*?);", str(response_login.headers))
        head_tax={'Cookie': cookies_login[0]}
        d = datetime.date(int(str(stardate)[:4]),int(str(stardate)[4:6]), 1)
        d2=datetime.date(int(str(enddate)[:4]),int(str(enddate)[4:6]), 1)
        this_month_start = datetime.date(d.year, d.month, 1)
        this_month_end = datetime.date(d2.year, d2.month, calendar.monthrange(d2.year, d2.month)[1])
        star='taxInputStartDate='+this_month_start.strftime('%Y-%m-%d')
        end='&taxInputEndDate='+this_month_end.strftime('%Y-%m-%d')
        url_seg='https://www.hntradesp.com/ocrm/tax/taxDutyPaidProof/exportDetailData?mode=address&city=HK&customerNo=&taxMonthStart=&taxMonthEnd=&'+star+end
        file_info = requests.get(url_seg,headers=head_tax)
        with open(r'd:/DATABASE/Taxproof/'+this_month_start.strftime('%Y-%m')+'完税证明.xlsx', 'wb') as file:
            file.write(file_info.content)
        
        print(this_month_start.strftime('%Y-%m')+'至'+this_month_end.strftime('%Y-%m')+"完税证明导出完成...")        