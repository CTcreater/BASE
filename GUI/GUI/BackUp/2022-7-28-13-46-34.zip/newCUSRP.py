# -*- coding: utf-8 -*-
"""
Created on Mon Jul 11 09:40:10 2022

@author: LV
used for mothly cumstomer Reporter
script 
"""


import xlrd
import numpy as np
import pandas as pd
import datetime 


class initialize():
    today=datetime.datetime.now()
    tomonth=int(datetime.datetime.now().strftime('%Y%m'))
    def __init__(self):
        xlsx_1=pd.ExcelFile('d:/DATABASE/all/会员台账.xls')
    
        xlsx_4 = pd.ExcelFile('d:/DATABASE/all/纳税.xlsx')
        xlsx_5 = pd.ExcelFile('c:/Users/LV/Desktop/DATA OF HNIEEC/业务预算/业务预算-招商服务2022-6.xlsx')
        
        self.df_1 = pd.read_excel(xlsx_1, 0)
        print('member book Data import successfully')
        self.df_2 = pd.read_csv('d:/DATABASE/all/销项发票明细.csv')
        print('Sale detail import successfully')
        self.df_3 = pd.read_excel('d:/DATABASE/all/客户开票.xlsx')
        print('value of trade import successfully')
        self.df_4 = pd.read_excel(xlsx_4, 0)
        self.df_41=pd.read_excel('d:/DATABASE/all/返税.xls',header=1)
        print('Tax Data import successfully')
        self.df_5 = pd.read_excel(xlsx_5, "收入明细表",header=1)
        print('financial statement-income import successfully')
        self.df_6 = pd.read_excel(xlsx_5, 1)
        print('financial statement-others import successfully')
        print('All Data import successfully')
    def feedback(self,a):
        if a==1:
            return self.df_1
        if a==2:
            return self.df_2
        if a==3:
            return self.df_3
        if a==4:
            return self.df_4
        if a==5:
            return self.df_5
        if a==6:
            return self.df_6
    def Sale_calculate(self,start=202001,end=tomonth,place='',method='all',whole=True):
        if whole==False:

            df_3=self.df_3.drop(self.df_3[(self.df_3['销方企业名称']=='海南迈科供应链管理有限公司')|(self.df_3['销方企业名称']=='海南兴威供应链有限公司')|(self.df_3['销方企业名称']=='海南泰智有色金属有限公司')|(self.df_3['销方企业名称']=='智威（海南）新材料科技有限公司')].index)
            df_2=self.df_2.drop(self.df_2[(self.df_2['销方企业名称']=='海南迈科供应链管理有限公司')|(self.df_2['销方企业名称']=='海南兴威供应链有限公司')|(self.df_2['销方企业名称']=='海南泰智有色金属有限公司')|(self.df_2['销方企业名称']=='智威（海南）新材料科技有限公司')].index)   


        if whole==True:
            df_3=self.df_3
            df_2=self.df_2
       
        if place=='海口':
            df_3=df_3[df_3['注册地']==place]
            df_2=df_2[df_2['销方企业注册地']==place]
            if method=='all':
                mask=(df_3['开票月份'] >= start) & (df_3['开票月份'] <= end) 
                userange=df_3.loc[mask]
                result=userange.groupby(['销方企业名称']).sum('价税合计')
                result.drop(columns=['客户编号','开票月份','金额', '税额', '累计价税合计', '份数'],inplace=True)

                
                return result
        
            if method == 'goods':
                start_new=str(start)[:4]+'-'+str(start)[4:6]
                end_new=str(end)[:4]+'-'+str(end)[4:6]
                mask=(df_2['开票日期'] >= start_new) & (df_2['开票日期'] <= end_new) 
                userange=df_2.loc[mask]
                result=userange.groupby(['商品和服务分类']).sum('价税合计')

                result.drop(columns=['发票代码','发票号码','销方客户编号','含税单价（元）'],inplace=True)
                return result
            if method == 'type':
                pass
                        
        if place=='洋浦':
            df_3=df_3[df_3['注册地']==place]
            df_2=df_2[df_2['销方企业注册地']==place]
            if method=='all':
                mask=(df_3['开票月份'] >= start) & (df_3['开票月份'] <= end) 
                userange=df_3.loc[mask]
                result=userange.groupby(['销方企业名称']).sum('价税合计')
                result.drop(columns=['客户编号','开票月份','金额', '税额', '累计价税合计', '份数'],inplace=True)
                return result         
                
            if method == 'goods':
                start_new=str(start)[:4]+'-'+str(start)[4:6]
                end_new=str(end)[:4]+'-'+str(end)[4:6]
                mask=(df_2['开票日期'] >= start_new) & (df_2['开票日期'] <= end_new) 
                userange=df_2.loc[mask]
                result=userange.groupby(['商品和服务分类']).sum('价税合计')
                result.drop(columns=['发票代码','发票号码','销方客户编号','含税单价（元）'],inplace=True)

                return result
            if method == 'type':
                pass
                
        else:
            if method=='all':
                mask=(df_3['开票月份'] >= start) & (df_3['开票月份'] <= end) 
                userange=df_3.loc[mask]
                result=userange.groupby(['销方企业名称']).sum('价税合计')
                result.drop(columns=['客户编号','开票月份','金额', '税额', '累计价税合计', '份数'],inplace=True)
                return result
            if method == 'goods':
                start_new=str(start)[:4]+'-'+str(start)[4:6]
                end_new=str(end)[:4]+'-'+str(end)[4:6]
                mask=(df_2['开票日期'] >= start_new) & (df_2['开票日期'] <= end_new) 
                userange=df_2.loc[mask]
                result=userange.groupby(['商品和服务分类']).sum('价税合计')
                result.drop(columns=['发票代码','发票号码','销方客户编号','含税单价（元）'],inplace=True)

                return result
            if method == 'type':
                pass
                
    def Tax_calculate(self,start=202001,end=tomonth,place='',method='all',whole=True): 
        if whole==False:
            try:
                df_4=self.df_4.drop(self.df_4[(self.df_4['公司名称']=='海南迈科供应链管理有限公司')|(self.df_4['公司名称']=='海南兴威供应链有限公司')|(self.df_4['公司名称']=='海南泰智有色金属有限公司')|(self.df_4['公司名称']=='智威（海南）新材料科技有限公司')].index)
            except:pass
        if whole==True:
            df_4=self.df_4
        
        if place=='海口':
            df_4=df_4[df_4['注册地']==place] 
            mask=(df_4['所属月份'] >= start) & (df_4['所属月份'] <= end) 
            userange=df_4.loc[mask]
            if method=='all':            
                result=userange.groupby(['公司名称']).sum('合计')

                result.drop(columns=['所属月份','实缴增值税','企业所得税','个人所得税','其他收入-工会经费','城建税','教育费附加','地方教育费附加','印花税'],inplace=True)
                return result
            if method=='type':
                result=userange.groupby(['公司名称']).sum()

                result.drop(columns=['所属月份'])
                return result
        if place=='洋浦':
            df_4=df_4[df_4['注册地']==place] 
            mask=(df_4['所属月份'] >= start) & (df_4['所属月份'] <= end) 
            userange=df_4.loc[mask]
            if method=='all':            
                result=userange.groupby(['公司名称']).sum('合计')
                result.drop(columns=['所属月份','实缴增值税','企业所得税','个人所得税','其他收入-工会经费','城建税','教育费附加','地方教育费附加','印花税'],inplace=True)

                return result
            if method=='type':
                result=userange.groupby(['公司名称']).sum()

                result.drop(columns=['所属月份'])
                return result
        else:
            mask=(df_4['所属月份'] >= start) & (df_4['所属月份'] <= end) 
            userange=df_4.loc[mask]
            if method=='all':            
                result=userange.groupby(['公司名称']).sum('合计')

                result.drop(columns=['所属月份','实缴增值税','企业所得税','个人所得税','其他收入-工会经费','城建税','教育费附加','地方教育费附加','印花税'],inplace=True)
                return result
            if method=='type':
                result=userange.groupby(['公司名称']).sum()

                result.drop(columns=['所属月份'])
                return result
            
    def TaxBack_calculate(self,start=202001,end=tomonth,place='',method='all',whole=True): 
        if whole==False:
            try:
               df_41=self.df_41=self.df_41.drop(self.df_41[(self.df_41['会员企业名称']=='海南迈科供应链管理有限公司')|(self.df_41['会员企业名称']=='海南兴威供应链有限公司')|(self.df_41['会员企业名称']=='海南泰智有色金属有限公司')|(self.df_41['会员企业名称']=='智威（海南）新材料科技有限公司')].index)
            except:pass
        if whole==True:
            df_41=self.df_41
            
        if place=='海口':
            df_41=df_41[df_41['注册地']==place] 

                    
            mask=(df_41['税收所属期'] >= start) & (df_41['税收所属期'] <= end) 
            userange=df_41.loc[mask]
            if method=='all':            
                result=userange.groupby(['会员企业名称']).sum()

                result.drop(columns=['税收所属期'],inplace=True)
                return result
            if method=='apply':
                result=userange.groupby(['会员企业名称']).sum()

                result.drop(columns=['税收所属期','纳税合计','增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '实返合计', '增值税.2', '城建税.2',
                                     '教育费附加.2', '印花税.2', '企业所得税.2', '金额', '原因', '应付', '已收', 
                                      'Unnamed: 35'],inplace=True)
                return result

            if method=='real':
                result=userange.groupby(['会员企业名称']).sum()

                result.drop(columns=['税收所属期','纳税合计', '增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '申请合计', '增值税.1', '城建税.1',
                                     '教育费附加.1', '印花税.1', '企业所得税.1'],inplace=True)
                return result
                        
        if place=='洋浦':
            df_41=df_41[self.df_41['注册地']==place] 
            if whole==False:
                try:
                    df_4.drop(DATA.df_4[(DATA.df_4['公司名称']=='海南迈科供应链管理有限公司')|(DATA.df_4['公司名称']=='海南兴威供应链有限公司')|(DATA.df_4['公司名称']=='海南泰智有色金属有限公司')|(DATA.df_4['公司名称']=='智威（海南）新材料科技有限公司')].index)
                except:pass
            mask=(df_41['税收所属期'] >= start) & (df_41['税收所属期'] <= end) 
            userange=df_41.loc[mask]
            if method=='all':            
                result=userange.groupby(['会员企业名称']).sum()

                result.drop(columns=['税收所属期'],inplace=True)
                return result
            if method=='apply':
                result=userange.groupby(['会员企业名称']).sum()

                result.drop(columns=['税收所属期','纳税合计','增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '实返合计', '增值税.2', '城建税.2',
                                     '教育费附加.2', '印花税.2', '企业所得税.2', '金额', '原因', '应付', '已收', 
                                      'Unnamed: 35'],inplace=True)
                return result

            if method=='real':
                result=userange.groupby(['会员企业名称']).sum()
  
                result.drop(columns=['税收所属期','纳税合计', '增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '申请合计', '增值税.1', '城建税.1',
                                     '教育费附加.1', '印花税.1', '企业所得税.1'],inplace=True)
                return result
          
        else:
            df_41=self.df_41
            mask=(df_41['税收所属期'] >= start) & (df_41['税收所属期'] <= end) 
            userange=df_41.loc[mask]
            if method=='all':            
                result=userange.groupby(['会员企业名称']).sum()

                result.drop(columns=['税收所属期'],inplace=True)
                return result
            if method=='apply':
                result=userange.groupby(['会员企业名称']).sum()

                result.drop(columns=['税收所属期','纳税合计','增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '实返合计', '增值税.2', '城建税.2',
                                     '教育费附加.2', '印花税.2', '企业所得税.2', '金额', '原因', '应付', '已收', 
                                      'Unnamed: 35'],inplace=True)
                return result

            if method=='real':
                result=userange.groupby(['会员企业名称']).sum()

                result.drop(columns=['税收所属期','纳税合计', '增值税', '城建税',
                                     '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税', '申请合计', '增值税.1', '城建税.1',
                                     '教育费附加.1', '印花税.1', '企业所得税.1'],inplace=True)
                return result
            
    def all_calculate(self,start=202001,end=tomonth,place='',method='all',whole=True):
        result_sale=self.Sale_calculate(start,end,place=place,method='all',whole=whole)
        result_sale['公司名称']=result_sale.index
        result_tax=self.Tax_calculate(start,end,place=place,method='type',whole=whole)
        result_taxback_detail=self.TaxBack_calculate(start,end,place=place,method='all',whole=whole)
        result_taxback_detail['公司名称']=result_taxback_detail.index
        result1=pd.merge(result_sale,result_tax,on='公司名称',how='outer')
        result=pd.merge(result1,result_taxback_detail,on='公司名称',how='outer')
        try:
            result.drop(columns=['纳税合计', '增值税', '城建税_y', '教育费附加_y', '地方教育费附加_y',
                                 '印花税_y', '企业所得税_y', '个税', '增值税.1', '城建税.1', '教育费附加.1', '印花税.1',
                                 '企业所得税.1', '增值税.2', '城建税.2', '教育费附加.2', '印花税.2', '企业所得税.2',
                                 '金额_y', '原因', '应付', '已收', 'Unnamed: 35' ],inplace=True)
        except:pass
        order=['公司名称','价税合计','合计','实缴增值税','城建税_x','教育费附加_x','地方教育费附加_x','印花税_x','企业所得税_x','个人所得税','其他收入-工会经费','申请合计','实返合计']
        return result[order]
            
    def report(self,start=202001,end=tomonth,place='',method='all',whole=True):
        mask3=(self.df_3['开票月份'] >= start) & (self.df_3['开票月份'] <= end) 
        df_3=self.df_3.loc[mask3]
        mask4=(self.df_4['所属月份'] >= start) & (self.df_4['所属月份'] <= end) 
        df_4=self.df_4.loc[mask4]
        mask41=(self.df_41['税收所属期'] >= start) & (self.df_41['税收所属期'] <= end) 
        df_41=self.df_41.loc[mask41]
        if whole == False:
            try:
                df_3=df_3.drop(df_3[(df_3['销方企业名称']=='海南迈科供应链管理有限公司')|(df_3['销方企业名称']=='海南兴威供应链有限公司')|(df_3['销方企业名称']=='海南泰智有色金属有限公司')|(df_3['销方企业名称']=='智威（海南）新材料科技有限公司')].index)
                df_4=df_4.drop(df_4[(df_4['公司名称']=='海南迈科供应链管理有限公司')|(df_4['公司名称']=='海南兴威供应链有限公司')|(df_4['公司名称']=='海南泰智有色金属有限公司')|(df_4['公司名称']=='智威（海南）新材料科技有限公司')].index)
            except:pass
        if place== '海口':
            df_3=df_3[df_3['注册地']==place]
            df_4=df_4[df_4['注册地']==place] 
            df_41=df_41[df_41['注册地']==place] 
        if place== '洋浦':
            df_3=df_3[df_3['注册地']==place]
            df_4=df_4[df_4['注册地']==place] 
            df_41=df_41[df_41['注册地']==place] 
        result_sale=df_3.groupby(['开票月份']).sum().drop(columns=['客户编号','累计价税合计','份数','金额','税额'])
        result_tax=df_4.groupby(['所属月份']).sum()
        result_taxback_apply=df_41.groupby(['税收所属期']).sum().drop(columns=['纳税合计', '增值税', '城建税', '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税','城建税.2', '教育费附加.2', '印花税.2', '企业所得税.2', '金额', '原因', '应付', '已收','Unnamed: 35'])
        result_taxback_real=df_41.groupby(['税收所属期']).sum().drop(columns=['纳税合计', '增值税', '城建税', '教育费附加', '地方教育费附加', '印花税', '企业所得税', '个税','申请合计','增值税.1', '城建税.1', '教育费附加.1', '印花税.1', '企业所得税.1','金额', '原因', '应付', '已收','Unnamed: 35'])
        result_taxback_detail=df_41.groupby(['税收所属期']).sum()

        if method == 'all_detail':
            result=pd.merge(pd.merge(result_sale,result_tax,left_index=True,right_index=True,how='left'),result_taxback_real,left_index=True,right_index=True,how='left')
            return result
        if method == 'all':
            result=pd.merge(pd.merge(result_sale,result_tax,left_index=True,right_index=True,how='left'),result_taxback_detail,left_index=True,right_index=True,how='left')
            return result
        if method == 'sale':       
            return result_sale
        if method == 'tax':       
            return result_tax
        if method == 'taxback_apply':       
            return result_taxback_apply
        if method == 'taxback_real':       
            return result_taxback_real
        if method == 'taxback_detail':       
            return result_taxback_detail
  
        

#查询匹配功能-用以索引每个公司当前的
def querry():
    print ('请将需要查询信息的公司在模板中输入>>>')
    df_que = pd.read_excel('d:/analyze program/查询匹配/查询列表.xlsx')
    tomonth=int(datetime.datetime.now().strftime('%Y%m'))
    DATA=initialize()
    df_1=DATA.feedback(3)
    DF_trade=df_1[df_1['开票月份']==tomonth]
    sum_dict=dict(zip(DF_trade['销方企业名称'],DF_trade['累计价税合计']))
    namelist=df_que['公司名称']
    resultlist=[]
    count1,count2= 0,0
    for i in namelist:
        try:
            resultlist.append(sum_dict[i])
            count1+=1
        except:
            resultlist.append('未查询到')
            count2+=1
    result=pd.DataFrame({'公司名称':namelist,'累计价税合计':resultlist})
    
    df_2=DATA.feedback(4)
    tax_result=df_2.groupby(['公司名称']).sum(['合计','实缴增值税','城建税','教育费附加','地方教育费附加','印花税','企业所得税','个人所得税','其他收入-工会经费'])
    result=pd.merge(result, tax_result.drop(columns=['所属月份']),how='left',on='公司名称')
    
    count=count1+count2
    print(result)
    print('querry finished !')
    print('total '+str(count))
    print('Find '+str(count1))
    print('No match '+str(count2))
    result.to_excel('d:/analyze program/匹配结果/匹配结果.xlsx',index=None)
   
def querry(start,end):
    print ('请将需要查询信息的公司在模板中输入>>>')
    print ('查询的时间区间为'+str(start)+'>>>'+str(end))
    df_que = pd.read_excel('d:/analyze program/查询匹配/查询列表.xlsx')
    DATA=initialize()
    df_1=DATA.feedback(3)
    DF_trade=df_1[df_1['开票月份']==end]
    DF_trade_star=df_1[df_1['开票月份']==start]
    sum_dict=dict(zip(DF_trade['销方企业名称'],DF_trade['累计价税合计']-DF_trade_star['累计价税合计']+DF_trade_star['价税合计']))
    namelist=df_que['公司名称']
    resultlist=[]
    count1,count2= 0,0
    for i in namelist:
        try:
            resultlist.append(sum_dict[i])
            count1+=1
        except:
            resultlist.append('未查询到')
            count2+=1
    result=pd.DataFrame({'公司名称':namelist,'累计价税合计':resultlist})
    
    df_raw=DATA.feedback(4)
    mask=(df_raw['所属月份'] >= start) & (df_raw['所属月份'] <= end)
    df_2=df_raw.loc[mask]
    tax_result=df_2.groupby(['公司名称']).sum(['合计','实缴增值税','城建税','教育费附加','地方教育费附加','印花税','企业所得税','个人所得税','其他收入-工会经费'])
    result=pd.merge(result, tax_result.drop(columns=['所属月份']),how='left',on='公司名称')
    
    count=count1+count2
    print(result)
    print('querry finished !')
    print('total '+str(count))
    print('Find '+str(count1))
    print('No match '+str(count2))
    result.to_excel('d:/analyze program/匹配结果/匹配结果.xlsx',index=None)
    

    
#日常查询数据


    


#while(True):
#    print('请输入功能:0.自动下载数据 1.数据报表 2.报告制作 3.数据分析 9.退出')
#    a=input()
#    if a=='0':
#        at.autoDownload()


