# -*- coding: utf-8 -*-
"""
Created on Wed Sep 21 16:03:16 2022

@author: LV
"""
import os
import xlwings as xw
import pandas as pd
from interval import Interval
import warnings
import newCUSRP 
import wordkiller as wk
import commitment



#'d:/analyze program/see.xlsx'
warnings.filterwarnings('ignore')

def make_material(from_date,end_date,place):
    file_dir='d:/analyze program/'
    Filename=place+str(from_date)+'至'+str(end_date)+'返税材料包'
    data=newCUSRP.initialize()
    df_sale=data.df_2
    
    app=xw.App(visible=False,add_book=False)
    
    
   
    if place == '海口':
        prove_df=data.df_81      
        star=str(from_date)[:4]+"/"+str(from_date)[4:6]+"/01"
        end=str(end_date)[:4]+"/"+str(end_date)[4:6]+"/31"
        mask=(prove_df['Unnamed: 12'] >= star) & (prove_df['Unnamed: 12'] <= end)      
        userange=prove_df.loc[mask]   #总的完税计算表合集
        customer_set=set(list(userange['Unnamed: 4']))
        
        os.makedirs(file_dir+Filename)
        wb =app.books.open('d:/DATABASE/完税证明模板.xlsx') 
        sh1 = wb.sheets(1)
        sh1.range("A3:AH9999").value = userange.values
        wb.save(file_dir+Filename+'/'+'所有完税证明合集.xlsx')
        wb.close()
        
        tax_sum=data.tax_raw_cube(DF=userange)
        seer=tax_sum.groupby('企业名称').sum()
        seer['纳税合计']=seer['增值税']+seer['城建税']+seer['教育费附加']+seer['地方教育附加']+seer['印花税']+seer['企业所得税']+seer['个人所得税']+seer['其他收入-工会经费']
        seer.reset_index(inplace=True)
        wk.make(df=seer, start=from_date, end=end_date, path=file_dir+Filename+'/'+'运营总部关于申请财政奖励的说明.docx')
        seer.drop(columns=['税收所属期','Unnamed: 0'],inplace=True)
        seer.to_excel(file_dir+Filename+'/'+'可申请奖励企业详情.xlsx')
        
        #完税证明丢弃掉无用字段
        userange_drop=userange.drop(columns=['Unnamed: 0','Unnamed: 6','Unnamed: 7','Unnamed: 8','Unnamed: 9','Unnamed: 14','Unnamed: 13','Unnamed: 24','增值税.1','城建税.1','印花税.1','企业所得税.1','个人所得税.1','Unnamed: 30','合计','省级财力贡献','市级财力贡献'])
        userange_drop.fillna(0, inplace=True)
        list_time=[data.today.strftime('%Y/%m/%d') for i in range(len(userange_drop))]
        userange_drop.insert(8,'申请时间',list_time)
        userange_drop['累计纳税']=userange_drop['增值税']+userange_drop['城建税']+userange_drop['教育费附加']+userange_drop['地方教育附加']+userange_drop['印花税']+userange_drop['企业所得税']+userange_drop['个人所得税']+userange_drop['其他收入-工会经费']
        userange_drop['平衡-企业所得税']=userange_drop['企业所得税']*0.34
        userange_drop['平衡-增值税']=userange_drop['增值税']*0.425
        userange_drop['平衡-城建税']=userange_drop['城建税']*0.85
        userange_drop['平衡-印花税']=userange_drop['印花税']*0.85
        userange_drop['平衡-个人所得税']=userange_drop['个人所得税']*0.4
        userange_drop['合计']=userange_drop['平衡-企业所得税']+userange_drop['平衡-增值税']+userange_drop['平衡-城建税']+userange_drop['平衡-印花税']+userange_drop['平衡-个人所得税']
        
        
        
        for i in  customer_set:
            df_3=data.df_3
            wb =app.books.open('d:/DATABASE/完税证明模板.xlsx') 
            sh1 = wb.sheets(1)
            cus_name=data.namedict.get(i)
            os.makedirs(file_dir+Filename+'/'+cus_name)
            temp=userange[userange['Unnamed: 4']==i]
            sh1.range("A3:AH99").value = temp.values
            wb.save(file_dir+Filename+'/'+cus_name+'/'+cus_name+'完税证明.xlsx')
            wb.close()
            
            wb_2=app.books.open('d:/DATABASE/产业扶持奖励明细表1.xlsx')
            sh2_1 = wb_2.sheets(1)
            sh2_2 = wb_2.sheets(2)
            temp2=userange_drop[userange_drop['Unnamed: 4']==i]
            sh2_2.range("A7:S1131").value = temp2.values
            
            lenth=(int(str(end_date)[:4])-int(str(from_date)[:4]))*12-int(str(from_date)[4:6])+int(str(end_date)[4:6])+1
            
            list_ym=[]
            for n in range(lenth):
                if n+int(str(from_date)[5:6])>12:
                    seg=from_date+n-12+100
                    list_ym.append(seg)
                else:
                    list_ym.append(from_date+n)
                    
            temp1=pd.DataFrame()
            temp1['企业名称']=[data.namedict.get(i) for q in range(lenth)]
            temp1['年月']=list_ym
            temp11=pd.merge(temp1, df_3,left_on=['企业名称','年月'],right_on=['销方企业名称','开票月份'],how='left')
            temp1_use=temp11.loc[:,['企业名称','年月','价税合计']]
            sh2_1.range("A5:C17").value = temp1_use.values
            
            userange_drop_temp=userange_drop[userange_drop['Unnamed: 4']==i]
            userange_drop_temp['key']=userange_drop_temp['Unnamed: 12'].apply(lambda x :x[:4]+x[5:7])
            s1=userange_drop_temp.groupby('key').sum()
            dict_all=s1.to_dict('index')
            
            
            tax_sum=[]
            tax_back=[]
            
            for x in list_ym:
                try:
                    tax_sum.append(dict_all[str(x)]['累计纳税'])
                except:
                    tax_sum.append('')
                    
                try:
                    tax_back.append(dict_all[str(x)]['合计'])
                except:
                    tax_back.append('')   
            temp12=pd.DataFrame()
            temp12['A']=tax_sum
            temp12['B']=tax_back
                    
            sh2_1.range("G5:h17").value = temp12.values

            wb_2.save(file_dir+Filename+'/'+cus_name+'/'+cus_name+'地方财政奖励计算表.xlsx')
            wb_2.close()   
            now=data.today.strftime('%Y年%m月%m日')
            path1=file_dir+Filename+'/'+cus_name+'/'+cus_name+'承诺书.docx'
            commitment.make(name=cus_name, Date=now, path=path1)
        
        
        app.quit()
        


            
    
    
    